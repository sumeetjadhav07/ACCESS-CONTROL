from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
import MySQLdb.cursors
import re

app = Flask(__name__)
app.secret_key = 'secretkey'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'bdsm6969'
app.config['MYSQL_DB'] = 'aslogin'

mysql = MySQL(app)

@app.route('/')
@app.route('/vuhome')
def log1():
	return render_template('vuhome.html')

@app.route('/login', methods =['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'username' in request.form and 'password' in request.form:
        username = request.form['username']
        password = request.form['password']
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts WHERE username = %s AND password = %s', (username, password, ))
        account = cursor.fetchone()
        
        if account:
            if account['authenticated']:
                session['loggedin'] = True
                session['id'] = account['id']
                session['username'] = account['username']
                msg = 'Logged in successfully !'
                return render_template('index.html', msg=msg)
            else:
                msg = 'User not authenticated. Please contact the administrator.'
        else:
            msg = 'Incorrect username / password !'
    return render_template('login.html', msg=msg)

@app.route('/db', methods = ["GET", "POST"])
def db1():
    if request.method == "POST":
        admin_username = "admin123"
        admin_password = "1757"
        input_username = request.form.get('username')
        input_password = request.form.get('password')

        if admin_username == input_username and admin_password == input_password:
            return redirect(url_for('display_data'))
        else:
            msg = 'Incorrect admin username / password !'

    return render_template("db.html")

@app.route('/display_data', methods = ["GET", "POST"])
def display_data():
    try:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        cursor.execute('SELECT * FROM accounts')
        data = cursor.fetchall()
        return render_template('display_data.html', data=data)
    except Exception as e:
        return f"An error occurred: {str(e)}"
	
@app.route('/authenticate_users', methods=['POST'])
def authenticate_users():
    try:
        cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
        user_ids = request.form.getlist('user_ids[]')
        for user_id in user_ids:
            cursor.execute('UPDATE accounts SET authenticated = TRUE WHERE id = %s', (user_id,))

        mysql.connection.commit()
        return redirect(url_for('display_data'))

    except Exception as e:
        return f"An error occurred: {str(e)}"
@app.route('/logout')
def logout():
	session.pop('loggedin', None)
	session.pop('id', None)
	session.pop('username', None)
	return redirect(url_for('login'))

@app.route('/register', methods =['GET', 'POST'])
def register():
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
		username = request.form['username']
		password = request.form['password']
		email = request.form['email']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute('SELECT * FROM accounts WHERE username = % s', (username, ))
		account = cursor.fetchone()
		if account:
			msg = 'Account already exists !'
		elif not re.match(r'[^@]+@[^@]+\.[^@]+', email):
			msg = 'Invalid email address !'
		elif not re.match(r'[A-Za-z0-9]+', username):
			msg = 'Username must contain only characters and numbers !'
		elif not username or not password or not email:
			msg = 'Please fill out the form !'
		else:
			cursor.execute('INSERT INTO accounts VALUES (NULL, % s, % s, % s)', (username, password, email, ))
			mysql.connection.commit()
			msg = 'You have successfully registered !'
	elif request.method == 'POST':
		msg = 'Please fill out the form !'
	return render_template('register.html', msg = msg)





app.run(host='localhost',port=5000)