from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from flask import Flask, render_template
import MySQLdb

app = Flask(__name__)
app.secret_key = 'secretkey'
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'bdsm6969'
app.config['MYSQL_DB'] = 'aslogin'

mysql = MySQL(app)

@app.route('/')
@app.route('/db', methods = ["GET", "POST"])
def db():
	msg = ''
	if request.method == 'POST' and 'username' in request.form and 'password' in request.form and 'email' in request.form :
		username = request.form['username']
		password = request.form['password']
		email = request.form['email']
		cursor = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
		cursor.execute('SELECT * FROM accounts WHERE username = % s AND password = % s AND email = % s', (username,password,email))
		output = cursor.fetchone()
		cursor. close 
		return render_template("db.html", data = output)
	else:
		return render_template("db.html")
	
app.run(host='localhost',port=5000)